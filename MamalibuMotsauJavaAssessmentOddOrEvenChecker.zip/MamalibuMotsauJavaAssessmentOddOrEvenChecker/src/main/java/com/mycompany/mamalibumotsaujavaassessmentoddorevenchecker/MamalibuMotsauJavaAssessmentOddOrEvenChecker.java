/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mamalibumotsaujavaassessmentoddorevenchecker;

/**
 *
 * @author Lenovo-User
 */
import java.util.Scanner;
public class MamalibuMotsauJavaAssessmentOddOrEvenChecker {

    public static void main(String[] args) {

        Scanner reader = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = reader.nextInt();

        if(num % 2 == 0)
            System.out.println(num + " is even");
        else
            System.out.println(num + " is odd");
    }
}
    

